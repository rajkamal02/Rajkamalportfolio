import type { Metadata } from "next";
import { Inter, Space_Grotesk } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "@/components/theme-provider";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
});

const spaceGrotesk = Space_Grotesk({
  variable: "--font-space-grotesk",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Rajkamal Vishwakarma - Data Analyst & Business Intelligence Portfolio",
  description: "Transforming ERP data into actionable business insights with Analytics & BI. Data Analyst with expertise in Python, SQL, Power BI, and Machine Learning.",
  keywords: ["Data Analyst", "Business Intelligence", "ERP Data Management", "Python", "SQL", "Power BI", "Machine Learning", "Data Visualization"],
  authors: [{ name: "Rajkamal Vishwakarma" }],
  openGraph: {
    title: "Rajkamal Vishwakarma - Data Analyst Portfolio",
    description: "Transforming ERP data into actionable business insights with Analytics & BI",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Rajkamal Vishwakarma - Data Analyst Portfolio",
    description: "Transforming ERP data into actionable business insights with Analytics & BI",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${inter.variable} ${spaceGrotesk.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          {children}
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}
