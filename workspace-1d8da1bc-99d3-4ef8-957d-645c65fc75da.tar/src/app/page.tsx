"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Moon, Sun, Download, ExternalLink, Github, Linkedin, MapPin, Mail, Send, Star, Code, Database, Brain, Zap, Camera, Upload, Briefcase, GraduationCap, Award, TrendingUp, Users, FileText, BarChart3, Settings, Cpu, Lightbulb, Target, Rocket } from "lucide-react"
import { useTheme } from "next-themes"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"

export default function Portfolio() {
  const { theme, setTheme } = useTheme()
  const { toast } = useToast()
  const [mounted, setMounted] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: ""
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [showProfileOptions, setShowProfileOptions] = useState(false)
  const [selectedProfile, setSelectedProfile] = useState("https://via.placeholder.com/400")

  const profileOptions = [
    { id: 1, url: "https://via.placeholder.com/400", label: "Professional", icon: <Briefcase className="h-4 w-4" /> },
    { id: 2, url: "https://via.placeholder.com/400/2563eb/ffffff", label: "Tech", icon: <Cpu className="h-4 w-4" /> },
    { id: 3, url: "https://via.placeholder.com/400/8b5cf6/ffffff", label: "Creative", icon: <Lightbulb className="h-4 w-4" /> },
    { id: 4, url: "https://via.placeholder.com/400/10b981/ffffff", label: "Modern", icon: <Rocket className="h-4 w-4" /> }
  ]

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    
    // Simulate form submission
    setTimeout(() => {
      toast({
        title: "Message Sent Successfully!",
        description: "Thank you for reaching out. I'll get back to you soon.",
      })
      setFormData({ name: "", email: "", message: "" })
      setIsSubmitting(false)
    }, 2000)
  }

  const handleProfileSelect = (url: string) => {
    setSelectedProfile(url)
    setShowProfileOptions(false)
    toast({
      title: "Profile Updated!",
      description: "Your profile picture has been updated successfully.",
    })
  }

  const educationData = [
    {
      degree: "MCA (AI & ML Specialization)",
      institution: "LNCT University",
      year: "2024",
      grade: "8.0 CGPA",
      icon: <Brain className="h-8 w-8 text-blue-400" />,
      background: "from-blue-500 to-cyan-500",
      related: "AI & Machine Learning",
      description: "Advanced studies in Artificial Intelligence and Machine Learning"
    },
    {
      degree: "B.Com (Computer Applications)",
      institution: "Barkatullah University",
      year: "2022",
      grade: "66.5%",
      icon: <Code className="h-8 w-8 text-green-400" />,
      background: "from-green-500 to-emerald-500",
      related: "Computer Science",
      description: "Commerce with specialization in Computer Applications"
    },
    {
      degree: "12th Commerce",
      institution: "Saraswati Shishu Mandir",
      year: "2018",
      grade: "61%",
      icon: <FileText className="h-8 w-8 text-yellow-400" />,
      background: "from-yellow-500 to-orange-500",
      related: "Commerce",
      description: "Higher Secondary Education in Commerce"
    },
    {
      degree: "10th",
      institution: "Saraswati Shishu Mandir",
      year: "2016",
      grade: "58%",
      icon: <GraduationCap className="h-8 w-8 text-purple-400" />,
      background: "from-purple-500 to-pink-500",
      related: "Foundation",
      description: "Secondary Education Foundation"
    }
  ]

  const workExperience = [
    {
      company: "Shufab Pvt. Ltd.",
      location: "Gurugram",
      position: "ERP Executive",
      period: "Jan 2025 – Present",
      icon: <Settings className="h-10 w-10 text-blue-400" />,
      background: "from-blue-500 to-indigo-500",
      industry: "Footwear Manufacturing",
      department: "ERP Management",
      keySkills: ["SAP ERP", "MM Module", "Data Management", "Process Optimization"],
      responsibilities: [
        "Managed ERP (MM Module) data for footwear manufacturing",
        "Handled Excel reports, purchase orders, BOMs",
        "Ensured accurate material data entry & process flow"
      ]
    },
    {
      company: "ROI Traders",
      location: "Bhopal",
      position: "Data Analyst",
      period: "Aug 2024 – Dec 2024",
      icon: <BarChart3 className="h-10 w-10 text-green-400" />,
      background: "from-green-500 to-teal-500",
      industry: "Stock Trading",
      department: "Analytics",
      keySkills: ["Stock Analysis", "Excel", "Dashboard Creation", "Portfolio Management"],
      responsibilities: [
        "Assisted in stock trading analysis (Nifty 50, Bank Nifty)",
        "Maintained stock records in Excel",
        "Built dashboards and performed portfolio analysis"
      ]
    }
  ]

  const projects = [
    {
      title: "Twitter Sentiment Analysis",
      description: "NLP + Web Scraping project for analyzing Twitter sentiment",
      technologies: ["Python", "NLP", "Web Scraping", "Sentiment Analysis"],
      icon: <Brain className="h-12 w-12 text-purple-400" />,
      gradient: "from-purple-500 to-pink-500",
      category: "NLP",
      difficulty: "Advanced",
      impact: "High"
    },
    {
      title: "Movie Recommendation System",
      description: "Collaborative filtering based movie recommendation engine",
      technologies: ["Python", "Machine Learning", "Collaborative Filtering", "Pandas"],
      icon: <Star className="h-12 w-12 text-yellow-400" />,
      gradient: "from-yellow-500 to-orange-500",
      category: "Machine Learning",
      difficulty: "Intermediate",
      impact: "Medium"
    },
    {
      title: "D-Mart Share Price Analysis",
      description: "Power BI dashboard for stock price analysis and visualization",
      technologies: ["Power BI", "Data Visualization", "Financial Analysis", "Excel"],
      icon: <TrendingUp className="h-12 w-12 text-green-400" />,
      gradient: "from-green-500 to-blue-500",
      category: "Business Intelligence",
      difficulty: "Intermediate",
      impact: "High"
    },
    {
      title: "AI Doctor Voicebot",
      description: "NLP + Conversational AI for medical assistance",
      technologies: ["NLP", "Conversational AI", "Python", "Speech Processing"],
      icon: <Users className="h-12 w-12 text-blue-400" />,
      gradient: "from-blue-500 to-cyan-500",
      category: "AI",
      difficulty: "Advanced",
      impact: "High"
    },
    {
      title: "Kidney Disease Classification",
      description: "Deep learning model for kidney disease prediction",
      technologies: ["Deep Learning", "Python", "TensorFlow", "Medical AI"],
      icon: <Cpu className="h-12 w-12 text-red-400" />,
      gradient: "from-red-500 to-pink-500",
      category: "Deep Learning",
      difficulty: "Advanced",
      impact: "High"
    },
    {
      title: "Amazon Sales Dashboard",
      description: "Power BI dashboard for sales analytics and reporting",
      technologies: ["Power BI", "Data Visualization", "Sales Analytics", "DAX"],
      icon: <BarChart3 className="h-12 w-12 text-orange-400" />,
      gradient: "from-orange-500 to-red-500",
      category: "Business Intelligence",
      difficulty: "Intermediate",
      impact: "Medium"
    },
    {
      title: "Rock vs Mine Prediction",
      description: "Machine learning classification for sonar data",
      technologies: ["Machine Learning", "Python", "Scikit-learn", "Classification"],
      icon: <Target className="h-12 w-12 text-indigo-400" />,
      gradient: "from-indigo-500 to-purple-500",
      category: "Machine Learning",
      difficulty: "Intermediate",
      impact: "Medium"
    }
  ]

  const skills = {
    "Programming": ["Python", "SQL", "R (Basics)", "C++ (Basics)"],
    "Data Analysis & Visualization": ["Excel (Advanced)", "Pandas", "NumPy", "Power BI", "Matplotlib", "Seaborn", "EDA", "Statistics"],
    "Machine Learning & AI": ["Scikit-learn", "NLP", "Deep Learning", "Regression", "Classification", "Model Evaluation"],
    "Tools & Platforms": ["Jupyter", "Google Colab", "VS Code", "Git/GitHub", "MS Office", "SAP ERP", "AI Tools"],
    "Databases": ["MySQL", "PostgreSQL"],
    "Soft Skills": ["Presentation", "Time Management", "Teamwork"]
  }

  const certifications = [
    "IBM (Coursera): Introduction to Data Science",
    "IBM (Coursera): Machine Learning with Python",
    "Coursera: Microsoft Excel"
  ]

  return (
    <div className="min-h-screen bg-background text-foreground relative overflow-hidden">
      {/* Decorative background elements */}
      <div className="decorative-circle w-96 h-96 top-20 left-10 opacity-20"></div>
      <div className="decorative-circle w-64 h-64 bottom-20 right-10 opacity-15"></div>
      <div className="decorative-line top-40"></div>
      <div className="decorative-line bottom-60"></div>

      {/* Navigation */}
      <nav className="fixed top-0 w-full glass backdrop-blur-md border-b z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-8">
              <button 
                onClick={() => scrollToSection("header")}
                className="text-xl font-bold gradient-text hover:scale-105 transition-transform"
              >
                RV
              </button>
              <div className="hidden md:flex space-x-6">
                <button 
                  onClick={() => scrollToSection("about")}
                  className="text-sm hover:text-primary transition-colors font-medium"
                >
                  About
                </button>
                <button 
                  onClick={() => scrollToSection("education")}
                  className="text-sm hover:text-primary transition-colors font-medium"
                >
                  Education
                </button>
                <button 
                  onClick={() => scrollToSection("experience")}
                  className="text-sm hover:text-primary transition-colors font-medium"
                >
                  Experience
                </button>
                <button 
                  onClick={() => scrollToSection("projects")}
                  className="text-sm hover:text-primary transition-colors font-medium"
                >
                  Projects
                </button>
                <button 
                  onClick={() => scrollToSection("skills")}
                  className="text-sm hover:text-primary transition-colors font-medium"
                >
                  Skills
                </button>
                <button 
                  onClick={() => scrollToSection("contact")}
                  className="text-sm hover:text-primary transition-colors font-medium"
                >
                  Contact
                </button>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Button
                variant="outline"
                size="icon"
                onClick={() => setTheme(theme === "light" ? "dark" : "light")}
                className="hover:scale-110 transition-transform"
              >
                <Sun className="h-[1.2rem] w-[1.2rem] rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
                <Moon className="absolute h-[1.2rem] w-[1.2rem] rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
                <span className="sr-only">Toggle theme</span>
              </Button>
              <Button variant="outline" size="sm" className="hidden sm:flex hover:scale-105 transition-transform">
                <Download className="mr-2 h-4 w-4" />
                Resume
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Header Section */}
      <section id="header" className="pt-24 pb-16 px-4 sm:px-6 lg:px-8 relative">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col lg:flex-row items-center gap-12 animate-slide-in-up">
            <div className="flex-1 text-center lg:text-left">
              <div className="mb-4">
                <Badge variant="secondary" className="mb-4 animate-float">
                  🚀 Data Analyst & BI Specialist
                </Badge>
              </div>
              <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold mb-6 gradient-text">
                Rajkamal Vishwakarma
              </h1>
              <h2 className="text-xl sm:text-2xl text-muted-foreground mb-6 font-medium">
                Data Analyst | Business Intelligence | ERP Data Management
              </h2>
              <p className="text-lg text-muted-foreground mb-8 max-w-2xl leading-relaxed">
                "Transforming ERP data into actionable business insights with Analytics & BI"
              </p>
              <div className="flex flex-wrap gap-4 justify-center lg:justify-start mb-8">
                <Button variant="outline" size="sm" className="hover:scale-105 transition-transform">
                  <Linkedin className="mr-2 h-4 w-4" />
                  LinkedIn
                </Button>
                <Button variant="outline" size="sm" className="hover:scale-105 transition-transform">
                  <Github className="mr-2 h-4 w-4" />
                  GitHub
                </Button>
                <Button variant="outline" size="sm" className="hover:scale-105 transition-transform">
                  Medium
                </Button>
                <Button className="hover:scale-105 transition-transform animate-glow">
                  <Download className="mr-2 h-4 w-4" />
                  Resume
                </Button>
              </div>
            </div>
            <div className="flex-shrink-0 relative">
              <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full blur-2xl opacity-30 animate-pulse"></div>
              <div className="relative">
                <Avatar className="w-80 h-80 profile-hover relative">
                  <AvatarImage src={selectedProfile} alt="Rajkamal Vishwakarma" />
                  <AvatarFallback className="text-6xl bg-gradient-to-br from-blue-500 to-purple-500 text-white">
                    RV
                  </AvatarFallback>
                </Avatar>
                <Button
                  size="icon"
                  className="absolute -bottom-2 -right-2 rounded-full bg-primary hover:bg-primary/80 animate-glow"
                  onClick={() => setShowProfileOptions(!showProfileOptions)}
                >
                  <Camera className="h-4 w-4" />
                </Button>
              </div>
              
              {/* Profile Options Modal */}
              {showProfileOptions && (
                <Card className="absolute top-full right-0 mt-2 w-64 glass z-10">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm">Choose Profile Style</CardTitle>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="grid grid-cols-2 gap-2">
                      {profileOptions.map((option) => (
                        <Button
                          key={option.id}
                          variant="outline"
                          size="sm"
                          className="flex flex-col items-center space-y-1 h-auto py-3"
                          onClick={() => handleProfileSelect(option.url)}
                        >
                          {option.icon}
                          <span className="text-xs">{option.label}</span>
                        </Button>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-16 px-4 sm:px-6 lg:px-8 relative">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4 gradient-text">About Me</h2>
            <div className="w-24 h-1 bg-gradient-to-r from-blue-500 to-purple-500 mx-auto rounded-full"></div>
          </div>
          <Card className="glass animate-slide-in-up">
            <CardContent className="pt-8">
              <p className="text-lg leading-relaxed text-center max-w-4xl mx-auto">
                I am a Data Analyst with experience in ERP and business data management, passionate about turning data into actionable insights. With hands-on projects in Machine Learning, Data Visualization, and Business Intelligence, I bring expertise in Python, SQL, Excel, and Power BI. I combine my ERP experience in manufacturing with data science skills to solve real-world problems and help businesses make better data-driven decisions.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Education Section */}
      <section id="education" className="py-16 px-4 sm:px-6 lg:px-8 relative">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4 gradient-text">Education</h2>
            <div className="w-24 h-1 bg-gradient-to-r from-green-500 to-blue-500 mx-auto rounded-full"></div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {educationData.map((edu, index) => (
              <Card key={index} className="glass hover:scale-105 transition-transform animate-slide-in-up group" style={{animationDelay: `${index * 0.1}s`}}>
                <CardHeader>
                  <div className="flex items-start space-x-4">
                    <div className={`p-3 rounded-xl bg-gradient-to-r ${edu.background} text-white group-hover:scale-110 transition-transform`}>
                      {edu.icon}
                    </div>
                    <div className="flex-1">
                      <CardTitle className="text-xl">{edu.degree}</CardTitle>
                      <CardDescription className="text-base">{edu.institution}</CardDescription>
                      <div className="flex items-center space-x-2 mt-2">
                        <Badge variant="outline" className="text-xs">{edu.year}</Badge>
                        <Badge variant="secondary" className="text-xs">{edu.grade}</Badge>
                      </div>
                      <div className="mt-2">
                        <Badge variant="outline" className="text-xs bg-primary/10 text-primary">
                          {edu.related}
                        </Badge>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">{edu.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Work Experience Section */}
      <section id="experience" className="py-16 px-4 sm:px-6 lg:px-8 relative">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4 gradient-text">Work Experience</h2>
            <div className="w-24 h-1 bg-gradient-to-r from-orange-500 to-red-500 mx-auto rounded-full"></div>
          </div>
          <div className="space-y-8">
            {workExperience.map((work, index) => (
              <Card key={index} className="glass hover:scale-105 transition-transform animate-slide-in-up group" style={{animationDelay: `${index * 0.1}s`}}>
                <CardHeader>
                  <div className="flex items-start space-x-4">
                    <div className={`p-4 rounded-xl bg-gradient-to-r ${work.background} text-white group-hover:scale-110 transition-transform`}>
                      {work.icon}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle className="text-xl">{work.position}</CardTitle>
                          <CardDescription className="text-base">{work.company} • {work.location}</CardDescription>
                          <Badge variant="secondary" className="mt-2">{work.period}</Badge>
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-2 mt-3">
                        <Badge variant="outline" className="text-xs bg-blue-500/10 text-blue-400">
                          {work.industry}
                        </Badge>
                        <Badge variant="outline" className="text-xs bg-green-500/10 text-green-400">
                          {work.department}
                        </Badge>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="mb-4">
                    <h4 className="text-sm font-medium mb-2">Key Skills:</h4>
                    <div className="flex flex-wrap gap-1">
                      {work.keySkills.map((skill, skillIndex) => (
                        <Badge key={skillIndex} variant="secondary" className="text-xs">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium mb-2">Responsibilities:</h4>
                    <ul className="space-y-2">
                      {work.responsibilities.map((resp, respIndex) => (
                        <li key={respIndex} className="flex items-start">
                          <span className="w-2 h-2 bg-primary rounded-full mt-2 mr-3 flex-shrink-0 animate-pulse"></span>
                          <span className="text-sm">{resp}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-16 px-4 sm:px-6 lg:px-8 relative">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4 gradient-text">Projects</h2>
            <div className="w-24 h-1 bg-gradient-to-r from-purple-500 to-pink-500 mx-auto rounded-full"></div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {projects.map((project, index) => (
              <Card key={index} className="project-card glass animate-slide-in-up group" style={{animationDelay: `${index * 0.1}s`}}>
                <CardHeader>
                  <div className="flex items-center space-x-3 mb-4">
                    <div className={`p-3 rounded-xl bg-gradient-to-r ${project.gradient} text-white group-hover:scale-110 transition-transform`}>
                      {project.icon}
                    </div>
                    <div className="flex-1">
                      <CardTitle className="text-lg">{project.title}</CardTitle>
                      <div className="flex items-center space-x-2 mt-1">
                        <Badge variant="outline" className="text-xs">{project.category}</Badge>
                        <Badge variant="secondary" className="text-xs">{project.difficulty}</Badge>
                        <Badge variant="outline" className={`text-xs ${project.impact === 'High' ? 'bg-red-500/10 text-red-400' : 'bg-yellow-500/10 text-yellow-400'}`}>
                          {project.impact} Impact
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <CardDescription>{project.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div>
                      <h4 className="text-sm font-medium mb-2">Technologies:</h4>
                      <div className="flex flex-wrap gap-1">
                        {project.technologies.map((tech, techIndex) => (
                          <Badge key={techIndex} variant="outline" className="text-xs hover:scale-105 transition-transform">
                            {tech}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div className="flex items-center justify-between pt-2">
                      <Button variant="outline" size="sm" className="text-xs">
                        <ExternalLink className="mr-1 h-3 w-3" />
                        View Details
                      </Button>
                      <div className="flex items-center space-x-1">
                        <Star className="h-3 w-3 text-yellow-400" />
                        <span className="text-xs text-muted-foreground">Featured</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-16 px-4 sm:px-6 lg:px-8 relative">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4 gradient-text">Skills</h2>
            <div className="w-24 h-1 bg-gradient-to-r from-cyan-500 to-blue-500 mx-auto rounded-full"></div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Object.entries(skills).map(([category, skillList], index) => (
              <Card key={index} className="glass hover:scale-105 transition-transform animate-slide-in-up group" style={{animationDelay: `${index * 0.1}s`}}>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center space-x-2">
                    <Code className="h-5 w-5 text-primary group-hover:scale-110 transition-transform" />
                    <span>{category}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {skillList.map((skill, skillIndex) => (
                      <Badge key={skillIndex} variant="secondary" className="hover:scale-105 transition-transform">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Certifications Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 relative">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4 gradient-text">Certifications</h2>
            <div className="w-24 h-1 bg-gradient-to-r from-yellow-500 to-orange-500 mx-auto rounded-full"></div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {certifications.map((cert, index) => (
              <Card key={index} className="glass hover:scale-105 transition-transform animate-slide-in-up group" style={{animationDelay: `${index * 0.1}s`}}>
                <CardContent className="pt-6">
                  <div className="flex items-center space-x-2">
                    <Award className="h-4 w-4 text-yellow-400 group-hover:scale-110 transition-transform" />
                    <span className="text-sm font-medium">{cert}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-16 px-4 sm:px-6 lg:px-8 relative">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4 gradient-text">Contact</h2>
            <div className="w-24 h-1 bg-gradient-to-r from-green-500 to-blue-500 mx-auto rounded-full"></div>
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <Card className="glass animate-slide-in-up">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Mail className="h-5 w-5 text-primary" />
                  <span>Get In Touch</span>
                </CardTitle>
                <CardDescription>
                  Feel free to reach out to me for any inquiries or collaboration opportunities.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="name">Name</Label>
                    <Input
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      placeholder="Your Name"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      placeholder="your.email@example.com"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="message">Message</Label>
                    <Textarea
                      id="message"
                      name="message"
                      value={formData.message}
                      onChange={handleInputChange}
                      placeholder="Your message here..."
                      rows={4}
                      required
                    />
                  </div>
                  <Button type="submit" disabled={isSubmitting} className="w-full hover:scale-105 transition-transform">
                    {isSubmitting ? (
                      <>
                        <Send className="mr-2 h-4 w-4 animate-spin" />
                        Sending...
                      </>
                    ) : (
                      <>
                        <Send className="mr-2 h-4 w-4" />
                        Send Message
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
            <Card className="glass animate-slide-in-up">
              <CardHeader>
                <CardTitle>Contact Information</CardTitle>
                <CardDescription>
                  Here's how you can reach me directly.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center space-x-3">
                  <div className="p-2 rounded-lg bg-muted">
                    <MapPin className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium">Location</p>
                    <p className="text-sm text-muted-foreground">Gurugram, Haryana, India</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="p-2 rounded-lg bg-muted">
                    <Mail className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium">Email</p>
                    <p className="text-sm text-muted-foreground">rv006090@gmail.com</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="p-2 rounded-lg bg-muted">
                    <Linkedin className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium">LinkedIn</p>
                    <p className="text-sm text-muted-foreground">Connect with me</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="p-2 rounded-lg bg-muted">
                    <Github className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium">GitHub</p>
                    <p className="text-sm text-muted-foreground">View my projects</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 sm:px-6 lg:px-8 border-t relative">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-muted-foreground">
            © {new Date().getFullYear()} Rajkamal Vishwakarma. All rights reserved.
          </p>
          <p className="text-sm text-muted-foreground mt-2">
            Built with Next.js, TypeScript, and Tailwind CSS
          </p>
        </div>
      </footer>
    </div>
  )
}